#include<gtk/gtk.h>

typedef struct
{
char type[20];
char nom[20];
char identifiant[20];
int jour;
int mois;
int annee;
int jour1;
int mois1;
int annee1;
int nombre;
char quotidien[20];
}plante;

void ajouter_pp(plante a);
plante chercher_pp(char identifiant[]);
void modifier_pp(char identifiant[],plante a);
void supprimer_pp (char identifiant[]);
void afficher_pp(GtkWidget *liste);

