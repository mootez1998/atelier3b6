#include <gtk/gtk.h>
int i,j;

void taux_dab(int annee);
void affi_abs(GtkWidget* treeview1,char*l);
void affi_ad_abs(GtkWidget* treeview1,char*l);
