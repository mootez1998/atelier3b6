#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "troupeau.h"
#include <gtk/gtk.h>
void ajouter_troupeau(troupeau t){
FILE * f;
f=fopen("troupeau.txt","a+") ;
if(f!=NULL) {
fprintf(f,"%s %s %s %s %s %s %s\n",t.sexe,t.poids,t.type,t.jour,t.mois,t.annee,t.id);
}
fclose(f); 
} 

void afficher_troupeau(GtkWidget *treeview5)
{
GtkCellRenderer *renderer ;
GtkTreeViewColumn *column ;
GtkTreeIter iter ;
GtkListStore *store ;
char sexe[100];
char poids[100] ;
char type [10];
char jour[10];
char mois [10];
char annee [10] ;
char id [10] ;
FILE *f ;
store =NULL ;
store=gtk_tree_view_get_model(treeview5);
if (store == NULL)
{
            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("sexe",renderer,"text",SEXE,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview5),column);
	    
            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("poids",renderer,"text",POIDS,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview5),column);
         
            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("type",renderer,"text",TYPE,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview5),column);

            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("jour",renderer,"text",JOUR,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview5),column);
            
            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("mois",renderer,"text",MOIS,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview5),column);
            
            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("annee",renderer,"text",ANNEE,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview5),column);

            renderer=gtk_cell_renderer_text_new ();
            column=gtk_tree_view_column_new_with_attributes ("id",renderer,"text",ID,NULL);
            gtk_tree_view_append_column(GTK_TREE_VIEW(treeview5),column);
}
            store =gtk_list_store_new(NUM_COL,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING ,G_TYPE_STRING ,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
            f=fopen("troupeau.txt","r");
            if (f!=NULL){
while (fscanf(f,"%s %s %s %s %s %s %s\n",sexe,poids,type,jour,mois,annee,id)!=EOF) {
            gtk_list_store_append(store,&iter);
            gtk_list_store_set
            (store,&iter,SEXE,sexe,TYPE,type,POIDS,poids,JOUR,jour,MOIS,mois,ANNEE,annee,ID,id,-1);
}
fclose(f);
}
            gtk_tree_view_set_model(GTK_TREE_VIEW(treeview5),GTK_TREE_MODEL(store));
            g_object_unref(store);
}
void modifier_troupeau(char sexe [20],char type [20],char poids [20],char jour [20],char mois[20],char annee[20],char id [20]){
troupeau t;
FILE *f;
FILE *f1;
f1=NULL ;
f=fopen("troupeau.txt","r");
f1=fopen("troupeau1.txt","a+");
if (f!= NULL)
{
while (fscanf(f,"%s %s %s %s %s %s %s\n ",t.sexe,t.poids,t.type,t.jour,t.mois,t.annee,t.id)!=EOF) {
if (strcmp(id,t.id)==0)
{
fprintf(f1,"%s %s %s %s %s %s %s\n",sexe,poids,type,jour,mois,annee,id) ;
}
else
fprintf(f1,"%s %s %s %s %s %s %s\n ",t.sexe,t.poids,t.type,t.jour,t.mois,t.annee,t.id) ;
}
fclose(f1);
fclose(f);
remove("troupeau.txt");
rename ("troupeau1.txt","troupeau.txt");
}
}
void supprimer_troupeau(char id[]){
troupeau t;
FILE *f;
FILE *f1 ;
f=fopen("troupeau.txt","r") ;
if (f!= NULL)
{
f1=fopen("troupeau1.txt","a");
while (fscanf(f,"%s %s %s %s %s %s %s\n",t.sexe,t.poids,t.type,t.jour,t.mois,t.annee,t.id)!=EOF) {
if (strcmp(id,t.id)!=0)
	{
	fprintf(f1,"%s %s %s %s %s %s %s\n",t.sexe,t.poids,t.type,t.jour,t.mois,t.annee,t.id) ;

	}
}


fclose(f1);
fclose(f);
remove("troupeau.txt");
rename("troupeau1.txt","troupeau.txt");
}
}
//validerchaine

int validerchaine(char vchaine[])
{
int a=0;
if ((vchaine[0]!='\0'))
a=1;
else
a=0;
return a;
}
//rechercher troupeau
int rechercher_id(char id2[])
{
troupeau t;
int b=0;
FILE*f;

f=fopen("troupeau.txt","r");

if (f!=NULL)
{
while(fscanf(f,"%s %s %s %s %s %s %s\n",t.sexe,t.poids,t.type,t.jour,t.mois,t.annee,t.id)!=EOF)
{

if(strcmp(t.id,id2)==0)
b=1;
else
b=0;
}
}
return b;
}
//exist id
int exist(char id[])
{
FILE*f=NULL;
 troupeau t;
f=fopen("troupeau.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s\n",t.sexe,t.poids,t.type,t.jour,t.mois,t.annee,t.id)!=EOF){
if(strcmp(t.id,id)==0)return 1;
}
fclose(f);
return 0;
}
//nombre troupeau
int nombre_troupeau(char type[])
{
FILE*f=NULL;
int n=0;
troupeau t;
f=fopen("troupeau.txt","r");
while(fscanf(f,"%s %s %s %s %s %s %s\n",t.sexe,t.poids,t.type,t.jour,t.mois,t.annee,t.id)!=EOF){
if(strcmp(t.type,type)==0)
n++;
}
return n;
}
