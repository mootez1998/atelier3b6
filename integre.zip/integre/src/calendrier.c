#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include "calendrier.h"
#include "callbacks.h"
#include "interface.h"
#include<gtk/gtk.h>
 
void ajouter_pp(plante a)
{
FILE *f=NULL;
f=fopen("plante.txt","a");
if (f!=NULL)
{
fprintf(f,"%s %s %s %d %d %d %d %d %d %d %s \n",a.nom, a.identifiant, a.type, a.jour, a.mois, a.annee, a.jour1, a.mois1, a.annee1, a.nombre,a.quotidien);
fclose (f);
}
}
//-------------------------------------------------------------------
plante chercher_pp(char identifiant[])
{
plante a;
FILE *f;
f=fopen("plante.txt","r");
if (f!=NULL)
{
while (fscanf(f," %s %s %s %d %d %d %d %d %d %d %s\n",a.nom, a.identifiant,a.type,&a.jour,&a.mois,&a.annee,&a.jour1,&a.mois1,&a.annee1, &a.nombre,a.quotidien)!=EOF)
{
if (strcmp(identifiant,a.identifiant)==0)
{
fprintf(f," %s %s %s %d %d %d %d %d %d %d %s\n",a.nom,a.identifiant,a.type,a.jour,a.mois,a.annee,a.jour1,a.mois1,a.annee1,a.nombre,a.quotidien);
}
}
}
fclose(f);
}

//--------------------------------------------------------------------
void modifier_pp(char identifiant[],plante a)
{

plante b;
FILE *f1,*f2;
f1=fopen("plante.txt","r");
f2=fopen("tmp.txt","w");
while (fscanf(f1,"%s %s %s %d %d %d %d %d %d %d %s\n",b.nom, b.identifiant, b.type,&b.jour,&b.mois,&b.annee,&b.jour1,&b.mois1,&b.annee1,&b.nombre,b.quotidien)!=EOF)
{
if (strcmp(identifiant,b.identifiant)!=0)
{
fprintf(f2,"%s %s %s %d %d %d %d %d %d %d %s\n",b.nom, b.identifiant, b.type, b.jour, b.mois, b.annee, b.jour1, b.mois1, b.annee1, b.nombre,b.quotidien);
}
else
{
fprintf(f2,"%s %s %s %d %d %d %d %d %d %d %s\n",a.nom, a.identifiant, a.type, a.jour, a.mois, a.annee, a.jour1,a.mois1, a.annee1, a.nombre,a.quotidien);
}
}
fclose(f1);
fclose(f2);

remove("plante.txt");
rename("tmp.txt","plante.txt");

}



//--------------------------------------------------------------------
void supprimer_pp(char identifiant[])
{
plante b;
FILE *f1,*f2;
f2=NULL;
f1=fopen("plante.txt","r");

if (f1==NULL)
{
return;
}
while (fscanf(f1," %s %s %s %d %d %d %d %d %d %d %s\n",b.nom, b.identifiant, b.type,&b.jour,&b.mois,&b.annee,&b.jour1,&b.mois1,&b.annee1,&b.nombre,b.quotidien)!=EOF)
{
if (strcmp(identifiant,b.identifiant)!=0)
{f2=fopen("tmp.txt","a+");
fprintf(f2," %s %s %s %d %d %d %d %d %d %d %s\n",b.nom, b.identifiant, b.type,b.jour,b.mois,b.annee,b.jour1,b.mois1,b.annee1,b.nombre,b.quotidien);

fclose(f2);
}}
fclose(f1);
remove("plante.txt");
rename("tmp.txt","plante.txt");
}



//-----------------------------------------------------------------------------------------------------------------------

void afficher_pp(GtkWidget *liste)
{
enum
{
TYPE,
NOM,
IDENTIFIANT,
JOUR,
MOIS,
ANNEE,
JOUR1,
MOIS1,
ANNEE1,
NOMBRE,
QUOTIDIEN,
COLUMN1
};
plante a;
 
   GtkCellRenderer * renderer;
   GtkTreeIter iter;
   GtkListStore *store;
   GtkTreeViewColumn *column;
char type[20];
char nom[20];
char identifiant[20];
char jour[20];
char mois[20];
char annee[20];
char jour1[20];
char mois1[20];
char annee1[20];
char nombre[20];
char quotidien[20];
FILE*f;
   store=NULL;
   store=gtk_tree_view_get_model(liste);
   if (store==NULL)
   {  


   renderer= gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("identifiant",renderer,"text",IDENTIFIANT,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer= gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",TYPE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
   column= gtk_tree_view_column_new_with_attributes("jour",renderer,"text",JOUR,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


   renderer= gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("mois",renderer,"text",MOIS,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("annee",renderer,"text",ANNEE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("jour1",renderer,"text",JOUR1,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("mois1",renderer,"text",MOIS1,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("annee1",renderer,"text",ANNEE1,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("nombre",renderer,"text",NOMBRE,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

   renderer= gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("quotidien",renderer,"text",QUOTIDIEN,NULL);
   gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



 


   store=gtk_list_store_new(COLUMN1,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);}
 
f=fopen("plante.txt","r");
   if (f==NULL)
   {
return;
   }
   else
   {
      while(fscanf(f," %s %s %s %s %s %s %s %s %s %s %s\n",nom,identifiant,type,jour,mois,annee,jour1,mois1,annee1,nombre,quotidien)!=EOF)
     {
      gtk_list_store_append(store, &iter);
      gtk_list_store_set(store,&iter,NOM,nom, IDENTIFIANT,identifiant,TYPE,type,JOUR,jour,MOIS,mois,ANNEE,annee,JOUR1,jour1,MOIS1,mois1,ANNEE1,annee1,NOMBRE,nombre,QUOTIDIEN,quotidien);
     }
  fclose(f);
  }
           gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
           g_object_unref (store);
}




