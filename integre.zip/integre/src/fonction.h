void ajoutercapdef(int id,char c[],int t);
void defectueux(float min,float max,int annee);
