#include <gtk/gtk.h>


void
on_retour_mod_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button3_mod_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button4_recherche_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficherM_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button4_eliminer_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_affichercapteur_clicked             (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button3_ajouter_clicked             (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button4_afficher_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_ajout_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button5_supp_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_supp_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_afficherS_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_MT_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_MA_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_MM_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour_capteur_clicked              (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button3_c_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button2_login_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button2_creation_clicked            (GtkWidget       *button,
                                        gpointer         user_data);

void
on_g_capteurs_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_g_calendrier_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_g_ouvrier_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_g_equipement_clicked                (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button27_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button28_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button29_clicked                    (GtkButton       *objet,
                                        gpointer         user_data);

void
on_button30_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button31_clicked                    (GtkButton       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview3_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button32_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button33_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview4_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button34_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button36_aj_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button38_mod_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button37_supp_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button39_nbre_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button36_jj_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button37_afficher_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button38_ret_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button36_suppp_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button37_rt_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button36_rech_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button37_aff_rech_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button39_mod_rech_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button38_ret_mod_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button36_afficher_nbre_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button26_gest_tro_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_valider1_clicked                    (GtkWidget      *button,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget      *button,
                                        gpointer         user_data);

void
on_valider2_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_valider3_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour2_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour4_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_supprime_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_retour3_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_validerf_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ans_clicked                         (GtkWidget      *button,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_rechercher_clicked                  (GtkWidget      *objet_graphique,
                                        gpointer         user_data);

void
on_quitter_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview10_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_anneeseche_clicked                  (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button41_clicked                    (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button40_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button39_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button38_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button37_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button36_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button42_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button43_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button44_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button46_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button45_clicked                    (GtkWidget      *button,
                                        gpointer         user_data);

void
on_button47_clicked                    (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button48_clicked                    (GtkWidget      *button,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview11_row_activated            (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
