#include <gtk/gtk.h>
enum
{
SEXE,
TYPE,
POIDS,
JOUR,
MOIS,
ANNEE,
ID,
NUM_COL
};
typedef struct troupeau{
char sexe [20];
char type [20];
char poids [20];
char jour [20];
char mois[20];
char annee[20];
char id [20];
} troupeau;


	void afficher_troupeau(GtkWidget *treeview1_liste);
	void ajouter_troupeau(troupeau t);
	void modifier_troupeau(char sexe [20],char type [20],char poids [20],char jour [20],char mois[20],char annee[20],char id [20]);
	void supprimer_troupeau(char id1[20]);
	int validerchaine(char vchaine[]);
	int exist(char id[]);
	int nombre_troupeau(char type[]);
	int rechercher_id(char id2[]);
	

